using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;
using UnityEngine.Experimental.Rendering.Universal;

public class CameraShake : MonoBehaviour
{
	public static CameraShake instance { get; private set; }

	private float curretTime;
	private bool isShake = false;

    private CinemachineVirtualCamera virCam;
    private CinemachineBasicMultiChannelPerlin camNoise;
	// Start is called before the first frame update
	private void Awake()
	{
		if (instance != null)
		{
			Debug.LogError("�ټ��� ī�޶� ����ũ ��ũ��Ʈ�� �������Դϴ�.");
		}
		instance = this;
	}
	//����,�ð�,ī�޶� �Է¹޾Ƽ� ī�޶� ����ũ�� �۵��ϴ� �Լ�
	private IEnumerator ShakeUpdate(float intensity, float time, CinemachineBasicMultiChannelPerlin camNoise)
	{
		if (isShake)
		{
			yield break;
		}
		isShake = true;
		camNoise.m_AmplitudeGain = intensity;
		curretTime = 0;

		while (true)
		{
			curretTime += Time.deltaTime;
			if (curretTime >= time)
			{
				break;
			}
			camNoise.m_AmplitudeGain = Mathf.Lerp(intensity, 0, curretTime / time);
			yield return null;
		}
		isShake = false;
		camNoise.m_AmplitudeGain = 0;
	}
	//���� ����Լ�
	public void ShakeCam(float intensity,float time, CinemachineBasicMultiChannelPerlin camNoise)
	{
		StopCoroutine(ShakeUpdate(intensity,time,camNoise));
		StartCoroutine(ShakeUpdate(intensity,time,camNoise));
	}
}
