using UnityEngine;

public class DontDestroy : MonoBehaviour
{

    void Start()
    {

        DontDestroyOnLoad(gameObject);
    }
}
