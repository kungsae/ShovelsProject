using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStat : LivingEntity
{
    [Header("����")]
    public int energy = 0;
    public int maxEnergy = 0;
    public int money = 0;
}
