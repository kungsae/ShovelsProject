using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class debug : MonoBehaviour
{
	public GameObject player;
	public GameObject test;
	private void Update()
	{
		//if (Input.GetKeyDown(KeyCode.U))
		//{
		//	player.transform.position = test.transform.position;
		//}
	}

}
